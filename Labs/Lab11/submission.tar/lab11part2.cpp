/*
  Group 5
*/

int main(int argc, char** argv)
{
  //increase stack size by 20 hex

  //move a variable at 14 hex into edi

  //moves rsp into rsi

  //variables getting assigned 10
  int a = 10;
  int b = 0;

  //use cin to recieve value and place it into -0x8 $rbp
  
  
  return 0;
}
